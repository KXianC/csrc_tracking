import os
import sys

from X_scoring_system.SingleInstruX import SingleInstruX

from data_handler.SingleInstru import *
from data_handler.stock import *
import matplotlib.pyplot as plt
import matplotlib
# %matplotlib inline
import matplotlib.dates as mdates

pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
import workdays
from pandas.tseries.offsets import BDay
import warnings
from utils.scoring_system_utils import *

warnings.filterwarnings('ignore')
import glob

pd.set_option('expand_frame_repr', False)  # 当列太多时不换行
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

"""
scoring_system_ma_method_01:
    只考虑当天candle,当 low < ma & close >= ma的情形。
    既可以是momentun, 也可以是rebounce.
    
"""
# TODO 考虑另外的方法，不周的逻辑： 1. t-n 上升/下降 趋势判断 2. 在触及均线之前给出信号，可以在均线附近买入

yml_path = '/tradeA/X_scoring_system/ymls/ema_v1.yaml'
loader = reading_yaml(yml_path)

# Global variables
signal_name = loader.get('universal').get('signal_name')
ma_window = loader.get('step2').get('ma_window')
error_rate = loader.get('step2').get('error_rate')


def scoring_system_ma_method_v1_X(ts_code, in_path, error_rate=error_rate):
    single_stock = SingleInstruX(ts_code, in_path)
    df = single_stock.append_minus_t_price(t_price_period=loader.get('step2').get('t_price_period'))

    # ma_window = [10, 13, 21, 45, 60, 100, 200]
    # col_ema_score_ma = ['ema_score_ma' + str(i) for i in ma_window]
    # col1 = ['ts_code', 'trade_date', 'low', 'close', 'pct_chg']
    # col = col1 + col_ema_score_ma

    closed = df['close'].values

    # New condition on previous high gap
    df['previous_high_gap'] = (df[['t{}high'.format(str(i)) for i in
                                   [*range(-loader.get('step2').get('t_price_period'), 0)]]].max(axis=1) / df[
                                   'close'] - 1) >= loader.get('step2').get('previous_high_gap')

    for window in ma_window:
        df['ema' + str(window)] = ta.MA(closed, timeperiod=window, matype=1)


    for window in ma_window:

        # Condition: ma45>100>200
        df['trending'] = (df['ema45'] > df['ema100']) & (df['ema100'] > df['ema200'])

        # Condition: all previous close price in a lookback window are above MA, so it is support, not ressitence
        df['privious_close_min>ema'+ str(window)] = df[['t{}close'.format(str(i)) for i in
                                   [*range(-loader.get('step2').get('t_price_period'), 0)]]].min(axis=1) >= df['ema' + str(window)]

        # Condition
        df['ema_low<=ma' + str(window)] = df.low <= df['ema' + str(window)] * error_rate
        df['ema_close>=ma' + str(window)] = df.close >= df['ema' + str(window)]

        # Combined Conditions
        df['ema_score_ma' + str(window)] = df['ema_low<=ma' + str(window)] & df['ema_close>=ma' + str(window)] & df[
            'previous_high_gap'] & df['privious_close_min>ema'+ str(window)] & df['trending']
        df['ema_score_ma' + str(window)] = df['ema_score_ma' + str(window)].astype(int)

        # df = df.loc[:, col]

        # filename = '{}_ma_score'.format(ts_code)

        # df.to_csv(output_path_final + '/' + filename + '.csv')

    return df


@decorator_timeit
def main():
    in_path = loader.get('step2').get('in_path')

    dir_name = datetime.datetime.today().strftime("%Y%m%d")
    out_path = loader.get('step2').get('out_path').format(
        signal_name, dir_name)
    makedir(out_path)

    # get hs300 index
    hs300_df = pd.read_csv('/tradeA/hs300_index.csv', index_col=0)
    hs300_list = hs300_df.con_code.tolist()

    # loop hs300 list
    if loader.get('universal').get('test_mode') == 'ON':
        instrument_list = loader.get('universal').get('test_mode_instrument')
    else:
        instrument_list = hs300_list

    for ts_code in tqdm(instrument_list):
        df = scoring_system_ma_method_v1_X(ts_code=ts_code, in_path=in_path)
        df.to_csv(out_path + ts_code + '.csv')


if __name__ == "__main__":
    main()
