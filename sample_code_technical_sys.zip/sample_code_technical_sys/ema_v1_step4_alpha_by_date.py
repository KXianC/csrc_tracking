import sys
import warnings

import matplotlib.pyplot as plt
import pandas as pd

from data_handler.stock import *
from utils.scoring_system_utils import *

pd.set_option('expand_frame_repr', False)  # 当列太多时不换行

pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)

warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

"""
Step 4: Read what produced in step 3, and output the signal for a date
"""

# Read YAML Config
yml_path = '/tradeA/X_scoring_system/ymls/ema_v1.yaml'
loader = reading_yaml(yml_path)

# Global variables
signal_name = loader.get('universal').get('signal_name')
ma_window = loader.get('step2').get('ma_window')
error_rate = loader.get('step2').get('error_rate')
score_select = loader.get('step3').get('score_select')

# define the return range
start = loader.get('universal').get('append_return_start')
end = loader.get('universal').get('append_return_end')
step = loader.get('universal').get('append_return_step')


def alpha_on_a_day(in_path, date, ma):
    data = pd.read_csv(in_path, index_col=0, parse_dates=['trade_date'])
    data = data[data['trade_date'] >= date].reset_index(drop=True)

    # append company name
    comp_name_df = pd.read_csv('/tradeA/stock_list.csv', index_col=0)
    data = data.merge(comp_name_df[['ts_code', 'name', 'industry']], how='left',
                      left_on='ts_code_x', right_on='ts_code', suffixes=('', '_com'))
    data['ts_code_num'] = data['ts_code_x'].apply(lambda x: str(x[:-3])).astype('str')

    # re-order the col
    ts = data['ts_code_num']
    name = data['name']
    industry = data['industry']
    data.drop(labels=['name', 'industry', 'ts_code_num'], axis=1, inplace=True)
    data.insert(1, 'industry', industry)
    data.insert(1, 'name', name)
    data.insert(1, 'ts_code_num', ts)

    # round to 2 decimals
    col_name_abs = ['t{}_ret_on_t1open'.format(i) for i in range(1, 41, 1)]
    col_name_exce = ['t{}_exce_ret'.format(i) for i in range(1, 41, 1)]
    data[col_name_abs + col_name_exce] = data[col_name_abs + col_name_exce].round(decimals=2)

    return data


if __name__ == "__main__":
    today = datetime.datetime.today().strftime("%Y%m%d")
    day = datetime.datetime.today().replace(day=1).strftime("%Y%m%d")
    for ma in ma_window:
        dir_name = datetime.datetime.today().strftime("%Y%m%d")
        in_path = loader.get('step4').get('in_path').format(
            signal_name, dir_name, ma)
        out_path = loader.get('step4').get('out_path').format(
            signal_name, ma)
        makedir(out_path)

        df = alpha_on_a_day(in_path, day, ma)

        cols_final = ['ts_code_x',
                      'name',
                      'industry',
                      'trade_date',
                      'year',
                      'month',
                      'day',
                      'close_x',
                      't1open',
                      't1_ret_on_t1open',
                      't2_ret_on_t1open',
                      't3_ret_on_t1open',
                      't4_ret_on_t1open',
                      't5_ret_on_t1open',
                      't6_ret_on_t1open',
                      't7_ret_on_t1open',
                      't8_ret_on_t1open',
                      't9_ret_on_t1open',
                      't10_ret_on_t1open',
                      't11_ret_on_t1open',
                      't12_ret_on_t1open',
                      't13_ret_on_t1open',
                      't14_ret_on_t1open',
                      't15_ret_on_t1open',
                      't16_ret_on_t1open',
                      't17_ret_on_t1open',
                      't18_ret_on_t1open',
                      't19_ret_on_t1open',
                      't20_ret_on_t1open',
                      't21_ret_on_t1open',
                      't22_ret_on_t1open',
                      't23_ret_on_t1open',
                      't24_ret_on_t1open',
                      't25_ret_on_t1open',
                      't26_ret_on_t1open',
                      't27_ret_on_t1open',
                      't28_ret_on_t1open',
                      't29_ret_on_t1open',
                      't30_ret_on_t1open',
                      't31_ret_on_t1open',
                      't32_ret_on_t1open',
                      't33_ret_on_t1open',
                      't34_ret_on_t1open',
                      't35_ret_on_t1open',
                      't36_ret_on_t1open',
                      't37_ret_on_t1open',
                      't38_ret_on_t1open',
                      't39_ret_on_t1open',
                      't40_ret_on_t1open',
                      ]
        df = df[cols_final]

        df.to_csv('{}{}_{}_{}_alpha.csv'.format(out_path, signal_name, day, today))
