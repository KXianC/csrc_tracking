import os
import sys

from X_scoring_system.SingleInstruX import SingleInstruX

from data_handler.SingleInstru import *
from data_handler.stock import *
import matplotlib.pyplot as plt
import matplotlib
# %matplotlib inline
import matplotlib.dates as mdates

pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
import workdays
from pandas.tseries.offsets import BDay
import warnings
from utils.scoring_system_utils import *

warnings.filterwarnings('ignore')
import glob

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

"""
Step 3: Create signal and return mapping panel for analysis and get the latest signal.


"""
# Read YAML Config
yml_path = '/tradeA/X_scoring_system/ymls/ema_v1.yaml'
loader = reading_yaml(yml_path)

# Global variables
signal_name = loader.get('universal').get('signal_name')
ma_window = loader.get('step2').get('ma_window')
error_rate = loader.get('step2').get('error_rate')
score_select = loader.get('step3').get('score_select')

# define the return range
start = loader.get('universal').get('append_return_start')
end = loader.get('universal').get('append_return_end')
step = loader.get('universal').get('append_return_step')


def ema_v1_panel(ts_code, in_path_score, in_path_return, ma):
    # get score data and filtering with rsi
    score = pd.read_csv('{}/{}.csv'.format(in_path_score, ts_code), index_col=0)
    score = score[score['ema_score_ma{}'.format(ma)] == score_select]

    # Get stock data and append return
    df_return = pd.read_csv('{}{}.csv'.format(in_path_return, ts_code), index_col=0)

    # merge the score and return
    result = score.merge(df_return, left_on='trade_date', right_on='trade_date', how='left')
    panel = result.merge(hs300, left_on='trade_date', right_on='trade_date', how='left', suffixes=('', '_hs'))

    # Filter out the nulls. Do not filter out nulls since it is needed for generating latest signal.
    # panel = panel[panel['p{}day_return_based_on_p1_v2_x'.format(str(end - 1))].notnull()]

    # Calculate the excess return
    for day in range(start, end, step):
        panel['t{}_exce_ret'.format(str(day))] = panel['t{}_ret_on_t1open'.format(str(day))] - panel[
            't{}_ret_on_t1open_hs'.format(str(day))]

    # add date cols for manual filtering in excel.
    try:
        # panel['trade_date'] = panel['trade_date'].apply(pd.to_datetime).dt.strftime('%Y%m%d')
        panel['year'] = panel['trade_date'].apply(lambda x: str(x)[0:4])
        panel['month'] = panel['trade_date'].apply(lambda x: str(x)[4:6])
        panel['day'] = panel['trade_date'].apply(lambda x: str(x)[-2:])

        # re-order the col
        s_year = panel['year']
        s_month = panel['month']
        s_day = panel['day']
        panel.drop(labels=['year', 'month', 'day'], axis=1, inplace=True)
        panel.insert(2, 'day', s_day)
        panel.insert(2, 'month', s_month)
        panel.insert(2, 'year', s_year)


    except Exception as e:
        print(ts_code)
        print(e)
    return panel


if __name__ == "__main__":

    # Variables
    dir_name = datetime.datetime.today().strftime("%Y%m%d")
    in_path_score = loader.get('step3').get('in_path_score').format(
        signal_name, dir_name)
    in_path_return = loader.get('step3').get('in_path_return')

    out_path_mid = loader.get('step3').get('out_path_mid').format(
        signal_name, dir_name)
    out_path = loader.get('step3').get('out_path').format(
        signal_name, dir_name)
    makedir(out_path_mid)

    # Get hs300 benchmark
    hs300_single_stock = SingleInstruX('399300.SZ', '/tradeA/')
    hs300 = hs300_single_stock.append_return()

    # get hs300 index
    hs300_df = pd.read_csv('/tradeA/hs300_index.csv', index_col=0)
    hs300_list = hs300_df.con_code.tolist()

    # loop hs300 list
    if loader.get('universal').get('test_mode') == 'ON':
        instrument_list = loader.get('universal').get('test_mode_instrument')
    else:
        instrument_list = hs300_list

    for ma in ma_window:
        panel_final = pd.DataFrame()
        for ts_code in tqdm(instrument_list):
            try:
                panel = ema_v1_panel(ts_code, in_path_score, in_path_return, ma)
                panel.to_csv('{}{}_{}.csv'.format(out_path_mid, ma, ts_code))
                panel_final = panel_final.append(panel, sort=False)
            except Exception as e:
                print(e)
        panel_final.reset_index(drop=True).to_csv('{}ma{}_panel_final.csv'.format(out_path, ma))
