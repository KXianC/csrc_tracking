import os
import sys
import sys

from utils.scoring_system_utils import makedir, reading_yaml

from data_handler.SingleInstru import *
from data_handler.stock import *
import matplotlib.pyplot as plt
import matplotlib
# %matplotlib inline
import matplotlib.dates as mdates

pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
import workdays
from pandas.tseries.offsets import BDay
import warnings

warnings.filterwarnings('ignore')
import glob

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

"""
Step 0: Update price data daily
Should move out to be shared by other signals.
HS 300 as the target for now to reduce run time.

Input: Tushare API

Output: Save csv to drive

"""


def get_data_from_api(ts_code, start_date, end_date, out_path):
    data = ts.pro_bar(ts_code=ts_code, adj='qfq', start_date=start_date, end_date=end_date)
    data = data.dropna(subset=['close'])
    data.to_csv(out_path + ts_code + '.csv')
    # time.sleep(1)
    return data


def update_price_dataframe(ts_code, start_date, end_date, out_path):
    old_data = pd.read_csv('{}{}.csv'.format(out_path, ts_code), index_col=0)

    new_data = ts.pro_bar(ts_code=ts_code, adj='qfq', start_date=start_date, end_date=end_date)
    new_data = new_data.dropna(subset=['close'])

    # Merge data, drop duplicates
    temp_df = pd.concat([new_data, old_data])
    temp_df['trade_date'] = temp_df['trade_date'].apply(str)
    data = temp_df.drop_duplicates(subset=['trade_date'], keep='first').reset_index(drop=True)

    # Output and override old data
    data.to_csv(out_path + ts_code + '.csv')
    return data


if __name__ == "__main__":
    # Read YAML Config
    yml_path = '/tradeA/X_scoring_system/ymls/rsi.yaml'
    loader = reading_yaml(yml_path)

    # get hs300 index
    hs300_df = pd.read_csv('/tradeA/hs300_index.csv', index_col=0)
    hs300_list = hs300_df.con_code.tolist()

    # Get start_date and end_date: T and T-14
    delta = 7
    end_date = date.today().strftime('%Y%m%d')
    start_date = (date.today() - datetime.timedelta(days=delta)).strftime('%Y%m%d')

    # Check the new data has been uploaded on Tushare side.
    data_check = ts.pro_bar(ts_code='600009.SH', adj='qfq', start_date=start_date, end_date=end_date)
    print(data_check.trade_date[0])

    if data_check.trade_date[0] != end_date:
        print('Old data date detected.')
        sys.exit("Process stops here.")

    else:
        print('new data has been uploaded on Tushare side. Continue the process')
        # loop into hs300 list
        out_path = loader.get('step0').get('out_path')
        makedir(out_path)
        cnt = 1
        err_code_list = []
        for ts_code in tqdm(hs300_list[:]):
            try:
                # To initialize datasets
                # get_data_from_api(ts_code, start_date='20050101', end_date='', out_path=out_path)

                # To update price dataframe
                update_price_dataframe(ts_code, start_date, end_date, out_path)
                cnt += 1
                if cnt % 50 == 0:
                    time.sleep(61)
                    print('cnt is {}, '.format(cnt), 'sleep 61s...')
            except Exception as e:
                print(e)
                err_code_list.append(ts_code)
                print(err_code_list)
