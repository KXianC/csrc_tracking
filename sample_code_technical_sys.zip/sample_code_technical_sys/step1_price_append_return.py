import os
import sys
from X_scoring_system.SingleInstruX import *
from utils.scoring_system_utils import reading_yaml

from data_handler.SingleInstru import *
from data_handler.stock import *
import matplotlib.pyplot as plt
import matplotlib
# %matplotlib inline
import matplotlib.dates as mdates

pd.set_option('display.max_columns', None)
# pd.set_option('display.max_rows', None)
import workdays
from pandas.tseries.offsets import BDay
import warnings

warnings.filterwarnings('ignore')
import glob

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

"""
Step 1: Tansform price data; add returns

Input: read in csv from step 0

Output: Save csv to drive

"""

if __name__ == "__main__":
    # Read YAML Config
    yml_path = '/tradeA/X_scoring_system/ymls/rsi.yaml'
    loader = reading_yaml(yml_path)

    # Variables
    in_path = '/tradeA/X_scoring_system_data/step0_price/'
    out_path = '/tradeA/X_scoring_system_data/step1_price_append_return/'

    # get hs300 index
    hs300_df = pd.read_csv('/tradeA/hs300_index.csv', index_col=0)
    hs300_list = hs300_df.con_code.tolist()

    # loop hs300 list
    for ts_code in tqdm(hs300_list[:]):
        single_stock = SingleInstruX(ts_code, in_path)
        data = single_stock.append_return(start=loader.get('universal').get('append_return_start'),
                                          end=loader.get('universal').get('append_return_end'),
                                          step=loader.get('universal').get('append_return_step'),
                                          max_entry_delay=loader.get('step1').get('max_entry_delay')
                                          )
        data.to_csv(out_path + ts_code + '.csv')
