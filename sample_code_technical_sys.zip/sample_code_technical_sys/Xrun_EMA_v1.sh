#!/usr/bin/env bash
set -e
eval "$(conda shell.bash hook)"
conda activate myenv
echo "The Python env I am using is:"
which python

echo "--------------------- Start Generating EMA V1 Signal ---------------------"
echo "--------------------- Step 2 ---------------------"
python /tradeA/X_scoring_system/ema_v1_step2_signal_cal.py
echo "--------------------- Step 3 ---------------------"
python /tradeA/X_scoring_system/ema_v1_step3_panel.py
echo "--------------------- Step 4 ---------------------"
python /tradeA/X_scoring_system/ema_v1_step4_alpha_by_date.py
echo "--------------------- All Done -------------------"
