import pandas as pd
import talib as ta

# Read YAML Config
from utils.scoring_system_utils import reading_yaml


class SingleInstruX(object):
    def __init__(self, ts_code, in_path):
        self.price_daily_bystock_path = in_path + '{}.csv'.format(ts_code)
        self.stock_name_path = '/tradeA/stock_list'
        self.code = ts_code

    def get_transform_data(self):
        # print('start get_transform_data')
        df = pd.read_csv(self.price_daily_bystock_path, index_col=0)
        df['date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
        df.set_index('date', inplace=True)
        df = df.iloc[::-1]
        return df

    def append_return(self, start=1, end=41, step=1, max_entry_delay=1):
        df = self.get_transform_data()
        for i in range(1,max_entry_delay+1):
            df['t{}open'.format(str(i))] = df.open.shift(-i)
            for n in range(start, end, step):
                df['t{}_ret_on_t{}open'.format(str(n),str(i))] = (df.close.shift(-n) / df['t{}open'.format(str(i))] - 1) * 100
        # df['t1_ret_on_t1open'] = df.close.shift(-1) / df.t1open - 1

        return df

    def get_rsi(self):
        df = self.get_transform_data()
        df['rsi'] = ta.RSI(df['close'].values)
        # for i in range(ran[0], ran[1]):
        #     df['p' + str(i) + '_rsi'] = df['rsi'].shift(-i)

        return df

    def get_indicator_for_rsi_divergence(self, lookback=30):
        df = self.get_transform_data()
        df['rsi'] = ta.RSI(df['close'].values)
        for i in range(-lookback, 0):
            df['t' + str(i) + '_rsi'] = df['rsi'].shift(-i)

        for i in range(-lookback, 0):
            df['t' + str(i) + '_low'] = df['low'].shift(-i)

        return df

    # This method is mainly for gap analysis
    def append_t_price(self, start=1, end=41, step=1, t_price_period=10):
        df = self.get_transform_data()
        for i in range(1,t_price_period+1):
            df['t{}open'.format(str(i))] = df.open.shift(-i)
            df['t{}close'.format(str(i))] = df.close.shift(-i)
            df['t{}high'.format(str(i))] = df.high.shift(-i)
            df['t{}low'.format(str(i))] = df.low.shift(-i)

        return df

    def append_minus_t_price(self, start=1, end=41, step=1, t_price_period=10):
        df = self.get_transform_data()
        for i in range(-t_price_period, 0):
            df['t{}open'.format(str(i))] = df.open.shift(-i)
            df['t{}close'.format(str(i))] = df.close.shift(-i)
            df['t{}high'.format(str(i))] = df.high.shift(-i)
            df['t{}low'.format(str(i))] = df.low.shift(-i)

        return df
